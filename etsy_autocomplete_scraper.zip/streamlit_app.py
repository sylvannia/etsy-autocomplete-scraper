
import requests
import pandas as pd
import time
import streamlit as st

# Function to get autocomplete suggestions from Etsy
def get_etsy_autocomplete(keyword):
    url = f"https://www.etsy.com/search/suggestions?q={keyword}&types=shop,listing"
    headers = {
        'User-Agent': 'Mozilla/5.0'
    }
    try:
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            data = response.json()
            suggestions = [item['text'] for item in data['results']]
            return suggestions
        else:
            return [f"Error {response.status_code}"]
    except Exception as e:
        return [f"Exception: {str(e)}"]

# Streamlit UI
st.title("Etsy Autocomplete Keyword Scraper")
st.write("Upload a CSV file with a column named 'Keyword' to get Etsy autocomplete suggestions.")

uploaded_file = st.file_uploader("Choose a CSV file", type="csv")

if uploaded_file is not None:
    try:
        keywords_df = pd.read_csv(uploaded_file)
        if 'Keyword' not in keywords_df.columns:
            st.error("The uploaded file must contain a 'Keyword' column.")
        else:
            keywords = keywords_df['Keyword'].dropna().unique()
            autocomplete_results = []

            with st.spinner('Fetching autocomplete suggestions...'):
                for kw in keywords:
                    suggestions = get_etsy_autocomplete(kw)
                    for suggestion in suggestions:
                        autocomplete_results.append({
                            "Input Keyword": kw,
                            "Autocomplete Suggestion": suggestion
                        })
                    time.sleep(1.5)  # Throttle requests

            autocomplete_df = pd.DataFrame(autocomplete_results)
            st.success("Autocomplete suggestions fetched successfully!")
            st.dataframe(autocomplete_df)

            # Download button
            csv = autocomplete_df.to_csv(index=False).encode('utf-8')
            st.download_button(
                label="Download CSV",
                data=csv,
                file_name='etsy_autocomplete_results.csv',
                mime='text/csv',
            )

    except Exception as e:
        st.error(f"Error processing file: {e}")
